/*
 * speech.h
 *
 *  Created on: Jun 6, 2019
 *      Author: trevo
 */

#ifndef SPEECH_H_
#define SPEECH_H_

void speech_say(pmod_result_t * p_results);
void speech_init(void);


#endif /* SPEECH_H_ */

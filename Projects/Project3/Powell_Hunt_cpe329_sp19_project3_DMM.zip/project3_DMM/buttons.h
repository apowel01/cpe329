/*
 * buttons.h
 *
 *  Created on: May 19, 2019
 *      Author: Amberley
 */

#ifndef BUTTONS_H_
#define BUTTONS_H_

void buttons_init(void);
uint8_t buttons_get_mode_ac(void);



#endif /* BUTTONS_H_ */

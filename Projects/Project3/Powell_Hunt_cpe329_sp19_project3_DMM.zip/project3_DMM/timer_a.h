/*
 * timer_a.h
 *
 *  Created on: Apr 23, 2019
 *      Author: trevo
 */

#ifndef TIMER_A_H_
#define TIMER_A_H_

void timer_a_init(void);

#endif /* TIMER_A_H_ */
